﻿namespace CngEdDCSA
{
    using System.Security.Cryptography;
    using System.Text;

    class Program
    {
        static void Main(string[] args)
        {
            // Default message and hash algorithm.
            var message = "Hello";
            var hash = "SHA256";

            try
            {
                // Update the message and hash algorithm if provided as command-line arguments.
                if (args.Length > 0) message = args[0];
                if (args.Length > 1) hash = args[1];

                // Convert the message to a byte array.
                var msg = Encoding.ASCII.GetBytes(message);

                // Define key creation parameters.
                var keyCreationParameters = new CngKeyCreationParameters
                {
                    ExportPolicy = CngExportPolicies.AllowExport | CngExportPolicies.AllowPlaintextExport, // Allow exporting keys.
                    KeyUsage = CngKeyUsages.Signing // Key will be used for signing.
                };

                // Create a private key for ECDSA signing.
                var CngPrivateKey = CngKey.Create(CngAlgorithm.ECDsaP256, null, keyCreationParameters);

                // Initialize ECDSA with the private key.
                var alice = new ECDsaCng(CngPrivateKey);

                // Export the private key as a byte array.
                var alicePrivate = alice.Key.Export(CngKeyBlobFormat.EccPrivateBlob);

                // Compute the hash of the message using the selected algorithm.
                var h = SHA256.HashData(msg); // Default to SHA256.
                alice.HashAlgorithm = CngAlgorithm.Sha256; // Set ECDSA hash algorithm.

                if (hash == "MD5")
                {
                    h = MD5.HashData(msg);
                    alice.HashAlgorithm = CngAlgorithm.MD5;
                }
                if (hash == "SHA1")
                {
                    h = SHA1.HashData(msg);
                    alice.HashAlgorithm = CngAlgorithm.Sha1;
                }
                if (hash == "SHA384")
                {
                    h = SHA384.HashData(msg);
                    alice.HashAlgorithm = CngAlgorithm.Sha384;
                }
                if (hash == "SHA512")
                {
                    h = SHA512.HashData(msg);
                    alice.HashAlgorithm = CngAlgorithm.Sha512;
                }

                // Generate a digital signature for the hash.
                var signature = alice.SignHash(h);

                // Export the public key as a byte array.
                var alicePublic = alice.Key.Export(CngKeyBlobFormat.EccPublicBlob);

                // Import the public key for verification.
                var bob = new ECDsaCng(CngKey.Import(alicePublic, CngKeyBlobFormat.EccPublicBlob));

                // Verify the signature using the public key and hash.
                var rtn = bob.VerifyHash(h, signature);

                // Print the results to the console.
                Console.WriteLine("Message:\t\t{0}", message);
                Console.WriteLine("Hash method:\t\t{0}", hash);
                Console.WriteLine("Hash:\t\t{0}", Convert.ToHexString(h));
                Console.WriteLine("\nSignature:\t{0}", Convert.ToHexString(signature));
                Console.WriteLine("\nVerified:\t{0}", rtn);

                // Display the private key in various formats.
                Console.WriteLine("\nPrivate key: {0}", Convert.ToHexString(alicePrivate));
                Console.WriteLine("\nPrivate key (PEM):\n{0}", alice.ExportECPrivateKeyPem());
                Console.WriteLine("\nPrivate key (DER):\n{0}", Convert.ToHexString(alice.ExportPkcs8PrivateKey()));

                // Display the public key in various formats.
                Console.WriteLine("\nPublic key: {0}", Convert.ToHexString(alicePublic));
                Console.WriteLine("\nPublic key (DER):\n{0}", Convert.ToHexString(alice.ExportPkcs8PrivateKey()));
                Console.WriteLine("Public key (PEM):\n{0}", alice.ExportSubjectPublicKeyInfoPem());
            }
            catch (Exception e)
            {
                // Handle and display any errors that occur.
                Console.WriteLine("Error: {0}", e.Message);
            }
        }
    }
}
